# Databricks notebook source
import dlt
from pyspark.sql import functions as F

BASE_PATH = "/Volumes/imdb/raw/imdb_raw"


@dlt.table(
    name="bronze_name_basics",
    comment="Raw ingestion of name.basics.tsv.gz from IMDb."
)
def bronze_name_basics():
    return (
        spark.read.format("csv")
            .option("sep", "\t")
            .option("header", "true")
            .load(f"{BASE_PATH}/name.basics.tsv.gz")
            .withColumn("load_ts", F.current_timestamp())
            .withColumn("src_file", F.lit("name.basics.tsv.gz"))
    )


@dlt.table(
    name="bronze_title_basics",
    comment="Raw ingestion of title.basics.tsv.gz from IMDb."
)
def bronze_title_basics():
    return (
        spark.read.format("csv")
            .option("sep", "\t")
            .option("header", "true")
            .load(f"{BASE_PATH}/title.basics.tsv.gz")
            .withColumn("load_ts", F.current_timestamp())
            .withColumn("src_file", F.lit("title.basics.tsv.gz"))
    )


@dlt.table(
    name="bronze_title_akas",
    comment="Raw ingestion of title.akas.tsv.gz from IMDb."
)
def bronze_title_akas():
    return (
        spark.read.format("csv")
            .option("sep", "\t")
            .option("header", "true")
            .load(f"{BASE_PATH}/title.akas.tsv.gz")
            .withColumn("load_ts", F.current_timestamp())
            .withColumn("src_file", F.lit("title.akas.tsv.gz"))
    )


@dlt.table(
    name="bronze_title_crew",
    comment="Raw ingestion of title.crew.tsv.gz from IMDb."
)
def bronze_title_crew():
    return (
        spark.read.format("csv")
            .option("sep", "\t")
            .option("header", "true")
            .load(f"{BASE_PATH}/title.crew.tsv.gz")
            .withColumn("load_ts", F.current_timestamp())
            .withColumn("src_file", F.lit("title.crew.tsv.gz"))
    )


@dlt.table(
    name="bronze_title_episode",
    comment="Raw ingestion of title.episode.tsv.gz from IMDb."
)
def bronze_title_episode():
    return (
        spark.read.format("csv")
            .option("sep", "\t")
            .option("header", "true")
            .load(f"{BASE_PATH}/title.episode.tsv.gz")
            .withColumn("load_ts", F.current_timestamp())
            .withColumn("src_file", F.lit("title.episode.tsv.gz"))
    )


@dlt.table(
    name="bronze_title_principals",
    comment="Raw ingestion of title.principals.tsv.gz from IMDb."
)
def bronze_title_principals():
    return (
        spark.read.format("csv")
            .option("sep", "\t")
            .option("header", "true")
            .load(f"{BASE_PATH}/title.principals.tsv.gz")
            .withColumn("load_ts", F.current_timestamp())
            .withColumn("src_file", F.lit("title.principals.tsv.gz"))
    )


@dlt.table(
    name="bronze_title_ratings",
    comment="Raw ingestion of title.ratings.tsv.gz from IMDb."
)
def bronze_title_ratings():
    return (
        spark.read.format("csv")
            .option("sep", "\t")
            .option("header", "true")
            .load(f"{BASE_PATH}/title.ratings.tsv.gz")
            .withColumn("load_ts", F.current_timestamp())
            .withColumn("src_file", F.lit("title.ratings.tsv.gz"))
    )
